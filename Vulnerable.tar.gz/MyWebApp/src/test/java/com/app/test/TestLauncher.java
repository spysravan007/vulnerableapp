package com.app.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;

import com.app.model.MyAppUser;
import com.app.service.LoginService;
import com.app.util.DbUtil;

public class TestLauncher {

    protected String getSaltString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 10)
            salt.append(SALTCHARS.charAt((int) (rnd.nextFloat() * SALTCHARS.length())));
        String saltStr = salt.toString();
        return saltStr;
    }

    @Test
    public void testSQLInjection() {
        try {
            Connection conn = DbUtil.getConnection();
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("DELETE FROM orders;");
            stmt.executeUpdate("DELETE FROM myappuser;");
            stmt.executeUpdate("INSERT INTO myappuser values('" + getSaltString() + "', '" + getSaltString() + "');");
            stmt.executeUpdate("INSERT INTO myappuser values('" + getSaltString() + "', '" + getSaltString() + "');");
            stmt.executeUpdate("INSERT INTO myappuser values('" + getSaltString() + "', '" + getSaltString() + "');");
            String fileName = "sql-injections.txt";
            List<String> list = new ArrayList<>();
            BufferedReader br = Files.newBufferedReader(Paths.get(fileName));
            list = br.lines().collect(Collectors.toList());
            LoginService service = new LoginService();
            MyAppUser user = service.findByUsernameAndPassword(list.get(0), list.get(1));
            assert (!user.getUsername().contentEquals(""));
        } catch (Exception e) {
            e.printStackTrace();
            assert (false);
        }
    }

    @Test
    public void testSonarReport() {
        try {
            Path path = Paths.get("target/sonar");
            assert (Files.exists(path));
            if (Files.exists(path)) {
                String fileName = "target/sonar/report-task.txt";
                List<String> list = new ArrayList<>();
                BufferedReader br = Files.newBufferedReader(Paths.get(fileName));
                list = br.lines().collect(Collectors.toList());

                String url = list.get(5).split("ceTaskUrl=")[1];
                HttpURLConnection httpClient = (HttpURLConnection) new URL(url).openConnection();
                httpClient.setRequestMethod("GET");
                BufferedReader in = new BufferedReader(new InputStreamReader(httpClient.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) 
                    response.append(line);
                assert(response.toString().contains(list.get(4).split("ceTaskId=")[1]));
            }
        } catch (Exception e) {
            e.printStackTrace();
            assert (false);
        }
    }
}
