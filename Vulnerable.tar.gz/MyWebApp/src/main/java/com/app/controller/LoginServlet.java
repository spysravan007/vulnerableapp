package com.app.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.model.MyAppUser;
import com.app.model.Orders;
import com.app.service.LoginService;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		MyAppUser myAppUser = new LoginService().findByUsernameAndPassword(username, password);
		PrintWriter writer = response.getWriter();
		if (myAppUser == null) {
			writer.println("<script>alert('Invalid credentials');window.location.replace('/');</script>");
		}else {
			writer.println("<h1>Hello " + myAppUser.getUsername().split("@")[0].substring(0, 1).toUpperCase() + myAppUser.getUsername().split("@")[0].substring(1).toLowerCase() + "</h1>");
			writer.println("<h3>Your Orders:</h3>");
			for(Orders o: myAppUser.getOrders()) {
				writer.println("<p>Order Id: "+o.getId()+", Units: "+o.getUnits()+", Price: "+o.getPrice()+"$</p>");
			}
		}
		writer.close();
	}
}
