package com.app.service;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.app.model.MyAppUser;
import com.app.model.Orders;
import com.app.util.DbUtil;

public class LoginService {

	public MyAppUser findByUsernameAndPassword(String username, String password) {
		MyAppUser myAppUser = null;
		List<Orders> orders = new ArrayList<Orders>();
		try {
			Statement stmt = DbUtil.getConnection().createStatement();
			ResultSet rs = stmt.executeQuery(
					"SELECT * FROM myappuser where username='" + username + "' AND password='" + password + "';");
			while (rs.next())
				myAppUser = new MyAppUser(rs.getString("username"), rs.getString("password"), orders);
			rs = stmt.executeQuery("SELECT * FROM orders where customer='" + username + "';");
			while (rs.next())
				orders.add(new Orders(rs.getInt("id"), rs.getInt("units"), rs.getInt("price"), myAppUser));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return myAppUser;
	}

}
