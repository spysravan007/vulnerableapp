package com.app.model;

import java.util.List;

public class MyAppUser {
	private String username;
	private String password;
	private List<Orders> orders;
	public MyAppUser(String username, String password, List<Orders> orders) {
		super();
		this.username = username;
		this.password = password;
		this.orders = orders;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public List<Orders> getOrders() {
		return orders;
	}
	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}
	@Override
	public String toString() {
		return "MyAppUser [username=" + username + ", password=" + password + ", orders=" + orders + "]";
	}
}