package com.app.model;

public class Orders {
	private int id ;
	private int units;
	private int price;
	private MyAppUser customer;
	public Orders(int id, int units, int price, MyAppUser customer) {
		super();
		this.id = id;
		this.units = units;
		this.price = price;
		this.customer = customer;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUnits() {
		return units;
	}
	public void setUnits(int units) {
		this.units = units;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public MyAppUser getCustomer() {
		return customer;
	}
	public void setCustomer(MyAppUser customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Orders [id=" + id + ", units=" + units + ", price=" + price + ", customer=" + customer + "]";
	}
}