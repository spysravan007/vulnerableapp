package com.app.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DbUtil {
	private static Connection conn = null;

	public static Connection getConnection() {
		try {
			if (conn == null || conn.isClosed()) {

				Class.forName("org.h2.Driver");
				conn = DriverManager.getConnection("jdbc:h2:~/test", "sa", "");
				initDb();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}

	public static void closeConnection(Connection conn) {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private DbUtil() {
	}

	private static void initDb() throws SQLException {
		Statement stmt = conn.createStatement();
		stmt.executeUpdate("DROP TABLE IF EXISTS myappuser;");
		stmt.executeUpdate("DROP TABLE IF EXISTS orders;");
		stmt.executeUpdate(
				"CREATE TABLE myappuser(username varchar2(30),password varchar2(10),PRIMARY KEY(username));");
		stmt.executeUpdate(
				"CREATE TABLE orders(id int,units int,price int,customer varchar2(30), PRIMARY KEY(id), FOREIGN KEY (customer) REFERENCES myappuser(username));");
		stmt.executeUpdate("INSERT INTO myappuser values('john@gmail.com', 'Pass');");
		stmt.executeUpdate("INSERT INTO myappuser values('chris@gmail.com', 'Pass');");
		stmt.executeUpdate("INSERT INTO myappuser values('jack@gmail.com', 'Pass');");
		stmt.executeUpdate("INSERT INTO myappuser values('jill@gmail.com', 'Pass');");
		stmt.executeUpdate("INSERT INTO orders values(1, 235, 10445, 'john@gmail.com');");
		stmt.executeUpdate("INSERT INTO orders values(2, 86, 8445, 'john@gmail.com');");
		stmt.executeUpdate("INSERT INTO orders values(3, 45, 10445, 'john@gmail.com');");
		stmt.executeUpdate("INSERT INTO orders values(4, 45, 10445, 'chris@gmail.com');");
		stmt.executeUpdate("INSERT INTO orders values(5, 235, 10445, 'chris@gmail.com');");
		stmt.executeUpdate("INSERT INTO orders values(6, 86, 8445, 'chris@gmail.com');");
		stmt.executeUpdate("INSERT INTO orders values(7, 45, 10445, 'jack@gmail.com');");
		stmt.executeUpdate("INSERT INTO orders values(8, 235, 10445, 'jack@gmail.com');");
		stmt.executeUpdate("INSERT INTO orders values(9, 86, 8445, 'jack@gmail.com');");
		stmt.executeUpdate("INSERT INTO orders values(10, 45, 10445, 'jill@gmail.com');");
		stmt.executeUpdate("INSERT INTO orders values(11, 235, 10445, 'jill@gmail.com');");
		stmt.executeUpdate("INSERT INTO orders values(12, 86, 8445, 'jill@gmail.com');");
	}
}
